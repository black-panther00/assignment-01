public class Rectangle implements Shape {
    public void draw() {
        int num = 15;
        int val = 10;
        for (int i = 1; i <= val; i++) {
            for (int j = 1; j <= num; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
