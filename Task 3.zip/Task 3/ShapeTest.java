public class ShapeTest {
        public static void main(String [] args){
            ShapeFactory shape=new ShapeFactory();

            //Test various shapes
            //square
            Shape square = shape.getShape("SQUARE");
            if (square != null){
                System.out.println("Square:");
                square.draw();
                System.out.println();
            }
            //circle
            Shape circle = shape.getShape("CIRCLE");
            if (circle != null){
                System.out.println("Circle:");
                circle.draw();
                System.out.println();
            }
            //rectangle
            Shape rectangle = shape.getShape("RECTANGLE");
            if (rectangle != null){
                System.out.println("Rectangle:");
                rectangle.draw();
                System.out.println();
            }

            Shape triangle  = shape.getShape("TRIANGLE");
            if (square != null){
                triangle.draw();
            }



        }
}
