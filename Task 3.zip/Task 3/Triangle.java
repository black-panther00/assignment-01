public class Triangle implements Shape{
    public void draw() {
        System.out.println("Invalid shape type provided. ");
    }
}

