public class RemoteControl {
    private final Command[] onCommands;
    private final Command[] offCommands;

    public RemoteControl(int slots) {
        onCommands = new Command[slots];
        offCommands = new Command[slots];
    }

    public void setCommand(int slot, Command onCommand, Command offCommand) {
        onCommands[slot] = onCommand;
        offCommands[slot] = offCommand;
    }


    public void onButtonPushed(int ignoredI) {

    }

    public void undoButtonPushed() {
    }

    public void offButtonPushed(int i) {
    }
}
