public class KitchenRoomLight implements Light {
    private int brightness;

    @Override
    public void on() {
        brightness = 100;
        System.out.println("Kitchen light is ON at full brightness.");
    }

    @Override
    public void off() {
        brightness = 0;
        System.out.println("Kitchen light is OFF.");
    }

    @Override
    public void dim(int level) {
        if (level < 0) {
            brightness = 0;
        } else brightness = Math.min(level, 100);
        System.out.println("Kitchen light is dimmed to " + brightness + "% brightness.");
    }

    public int getBrightness() {
        return brightness;
    }
}

